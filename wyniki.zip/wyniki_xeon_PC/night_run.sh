./RunExperiments ./bench-openmp/integrate  1.0 2.0 100000000000
./RunExperiments ./bench-openmp/heat 40000 0.2
./RunExperiments ./bench-openmp/fft 32768
